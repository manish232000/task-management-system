document.addEventListener('DOMContentLoaded', (event) => {
    fetchTasks();
});

function addTask() {
    const taskName = document.getElementById('taskName').value;
    if (taskName) {
        fetch('http://localhost:3000/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: taskName })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Task added:', data);
            document.getElementById('taskName').value = '';
            fetchTasks();
        })
        .catch(error => {
            console.error('Error adding task:', error);
        });
    }
}

function fetchTasks() {
    fetch('http://localhost:3000/tasks')
        .then(response => response.json())
        .then(data => {
            const taskList = document.getElementById('taskList');
            taskList.innerHTML = '';
            data.forEach(task => {
                const li = document.createElement('li');
                li.textContent = task.name;
                li.dataset.id = task.id;
                li.classList.toggle('completed', task.completed);

                // Add edit button
                const editButton = document.createElement('button');
                editButton.textContent = 'Edit';
                editButton.onclick = () => editTask(task.id, task.name);
                li.appendChild(editButton);

                // Add delete button
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.onclick = () => deleteTask(task.id);
                li.appendChild(deleteButton);

                // Add toggle completion button
                const toggleButton = document.createElement('button');
                toggleButton.textContent = task.completed ? 'Mark Incomplete' : 'Mark Complete';
                toggleButton.onclick = () => toggleTaskCompletion(task.id, !task.completed);
                li.appendChild(toggleButton);

                taskList.appendChild(li);
            });
        })
        .catch(error => {
            console.error('Error fetching tasks:', error);
        });
}


function editTask(id, currentName) {
    const newName = prompt('Enter new task name:', currentName);
    if (newName) {
        fetch(`http://localhost:3000/tasks/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: newName, completed: false })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Task updated:', data);
            fetchTasks();
        })
        .catch(error => {
            console.error('Error updating task:', error);
        });
    }
}

function toggleTaskCompletion(id, completed) {
    fetch(`http://localhost:3000/tasks/${id}/completed`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ completed })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Task completion updated:', data);
        fetchTasks();
    })
    .catch(error => {
        console.error('Error updating task completion:', error);
    });
}


function deleteTask(id) {
    fetch(`http://localhost:3000/tasks/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        console.log('Task deleted:', data);
        fetchTasks();
    })
    .catch(error => {
        console.error('Error deleting task:', error);
    });
}

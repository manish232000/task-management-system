const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

// MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '2314', // Replace with your MySQL root password
    database: 'task_management'
});

db.connect(err => {
    if (err) {
        console.error('MySQL connection error:', err);
        process.exit(1);
    }
    console.log('MySQL connected...');
});
const renumberIDs = () => {
    const sql = `
        SET @new_id = 0;
        UPDATE tasks
        SET id = (@new_id := @new_id + 1)
        ORDER BY id;
        ALTER TABLE tasks AUTO_INCREMENT = 1;
    `;
    return new Promise((resolve, reject) => {
        db.query(sql, (err) => {
            if (err) return reject(err);
            resolve();
        });
    });
};


// Ensure database and table exist
db.query('CREATE DATABASE IF NOT EXISTS task_management', err => {
    if (err) {
        throw err;
    }
    db.query('USE task_management', err => {
        if (err) {
            throw err;
        }
        db.query(`CREATE TABLE IF NOT EXISTS tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            completed BOOLEAN DEFAULT FALSE
        )`, err => {
            if (err) {
                throw err;
            }
            console.log('Table `tasks` exists or was created.');
        });
    });
});

// Route to get all tasks
app.get('/tasks', (req, res) => {
    db.query('SELECT * FROM tasks ORDER BY id', (err, results) => {
        if (err) {
            console.error('Error fetching tasks:', err);
            return res.status(500).send(err);
        }
        res.json(results);
    });
});



app.post('/tasks', (req, res) => {
    const { name } = req.body;
    console.log('Received POST /tasks:', req.body); // Log the request body
    const sql = 'INSERT INTO tasks (name) VALUES (?)';
    db.query(sql, [name], (err, result) => {
        if (err) {
            console.error('Error inserting task:', err);
            return res.status(500).send(err);
        }
        console.log('Task inserted with ID:', result.insertId); // Log the result of the insert operation
        res.json({ id: result.insertId, name, completed: false });
    });
});




app.put('/tasks/:id', (req, res) => {
    const { id } = req.params;
    const { name, completed } = req.body;
    const sql = 'UPDATE tasks SET name = ?, completed = ? WHERE id = ?';
    db.query(sql, [name, completed, id], (err, result) => {
        if (err) {
            console.error('Error updating task:', err);
            return res.status(500).send(err);
        }
        res.json({ id, name, completed });
    });
});


// Route to delete a task
app.delete('/tasks/:id', async (req, res) => {
    const { id } = req.params;

    // Delete the task
    db.query('DELETE FROM tasks WHERE id = ?', [id], async (err) => {
        if (err) {
            console.error('Error deleting task:', err);
            return res.status(500).send(err);
        }

        // Renumber IDs
        try {
            await renumberIDs();
            res.sendStatus(200);
        } catch (error) {
            console.error('Error renumbering IDs:', error);
            res.status(500).send('Error renumbering IDs');
        }
    });
});

// Toggle task completion
app.put('/tasks/:id/completed', (req, res) => {
    const { id } = req.params;
    const { completed } = req.body;
    const sql = 'UPDATE tasks SET completed = ? WHERE id = ?';
    db.query(sql, [completed, id], (err, result) => {
        if (err) {
            console.error('Error updating task completion:', err);
            return res.status(500).send(err);
        }
        res.json({ id, completed });
    });
});


app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
